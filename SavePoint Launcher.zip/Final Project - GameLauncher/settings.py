import resources_rcc

from PyQt5 import QtCore, QtGui, QtWidgets
from library import Ui_centralWidget


class Ui_settingsUI(object):
    def setupUi(self, settingsUI):
        settingsUI.setObjectName("settingsUI")
        settingsUI.resize(1280, 780)
        settingsUI.setStyleSheet(
            "#settingsUI { border-image: url(:/images/background.PNG); }"
        )
        self.lbl_user = QtWidgets.QLabel(settingsUI)
        self.lbl_user.setGeometry(QtCore.QRect(480, 160, 151, 41))
        font = QtGui.QFont()
        font.setFamily("Sylfaen")
        font.setPointSize(16)
        self.lbl_user.setFont(font)
        self.lbl_user.setStyleSheet(
            "background-color: #FFFFFF;"
            "color: #333333;"
            "border-radius: 4px;"
            "padding: 4px 8px;"
        )
        self.lbl_user.setObjectName("lbl_user")
        self.lbl_changeuser = QtWidgets.QLabel(settingsUI)
        self.lbl_changeuser.setGeometry(QtCore.QRect(480, 210, 91, 31))
        font = QtGui.QFont()
        font.setFamily("Sylfaen")
        font.setPointSize(10)
        self.lbl_changeuser.setFont(font)
        self.lbl_changeuser.setStyleSheet("""
        #lbl_changeuser {
        background-color: #FFFFFF;
        color: #333333;
        font-size: 10px;        /* Smaller font to fit text */
        border-radius: 4px;
        padding: 2px;
        }
        """)
        self.lbl_changeuser.setObjectName("lbl_changeuser")
        self.le_changeuser = QtWidgets.QLineEdit(settingsUI)
        self.le_changeuser.setGeometry(QtCore.QRect(570, 210, 191, 31))
        self.le_changeuser.setObjectName("le_changeuser")
        self.lbl_confirmpassw = QtWidgets.QLabel(settingsUI)
        self.lbl_confirmpassw.setGeometry(QtCore.QRect(480, 250, 91, 31))
        font = QtGui.QFont()
        font.setFamily("Sylfaen")
        font.setPointSize(10)
        self.lbl_confirmpassw.setFont(font)
        self.lbl_confirmpassw.setStyleSheet("""
        #lbl_confirmpassw {
        background-color: #FFFFFF;
        color: #333333;
        font-size: 10px;        /* Smaller font to fit text */
        border-radius: 4px;
        padding: 2px;
        }
        """)
        self.lbl_confirmpassw.setObjectName("lbl_confirmpassw")
        self.le_confirmpassw = QtWidgets.QLineEdit(settingsUI)
        self.le_confirmpassw.setGeometry(QtCore.QRect(570, 250, 191, 31))
        self.le_confirmpassw.setEchoMode(QtWidgets.QLineEdit.Password)
        self.le_confirmpassw.setObjectName("le_confirmpassw")
        self.lbl_passw = QtWidgets.QLabel(settingsUI)
        self.lbl_passw.setGeometry(QtCore.QRect(480, 310, 151, 41))
        font = QtGui.QFont()
        font.setFamily("Sylfaen")
        font.setPointSize(16)
        self.lbl_passw.setFont(font)
        self.lbl_passw.setStyleSheet(
            "background-color: #FFFFFF;\n"
            "color: #333333;"
            "border-radius: 4px;"
            "padding: 4px 8px;"
        )
        self.lbl_passw.setObjectName("lbl_passw")
        self.lbl_newpassw = QtWidgets.QLabel(settingsUI)
        self.lbl_newpassw.setGeometry(QtCore.QRect(480, 400, 91, 31))
        font = QtGui.QFont()
        font.setFamily("Sylfaen")
        font.setPointSize(10)
        self.lbl_newpassw.setFont(font)
        self.lbl_newpassw.setStyleSheet("""
        #lbl_newpassw {
        background-color: #FFFFFF;
        color: #333333;
        font-size: 10px;        /* Smaller font to fit text */
        border-radius: 4px;
        padding: 2px;
        }
        """)
        self.lbl_newpassw.setObjectName("lbl_newpassw")
        self.lbl_currentpassw = QtWidgets.QLabel(settingsUI)
        self.lbl_currentpassw.setGeometry(QtCore.QRect(480, 360, 91, 31))
        font = QtGui.QFont()
        font.setFamily("Sylfaen")
        font.setPointSize(10)
        self.lbl_currentpassw.setFont(font)
        self.lbl_currentpassw.setStyleSheet("""
        #lbl_currentpassw {
        background-color: #FFFFFF;
        color: #333333;
        font-size: 10px;        /* Smaller font to fit text */
        border-radius: 4px;
        padding: 2px;
        }
        """)
        self.lbl_currentpassw.setObjectName("lbl_currentpassw")
        self.le_currentpassw = QtWidgets.QLineEdit(settingsUI)
        self.le_currentpassw.setGeometry(QtCore.QRect(570, 360, 191, 31))
        self.le_currentpassw.setEchoMode(QtWidgets.QLineEdit.Password)
        self.le_currentpassw.setObjectName("le_currentpassw")
        self.le_newpassw = QtWidgets.QLineEdit(settingsUI)
        self.le_newpassw.setGeometry(QtCore.QRect(570, 400, 191, 31))
        self.le_newpassw.setEchoMode(QtWidgets.QLineEdit.Password)
        self.le_newpassw.setObjectName("le_newpassw")
        self.le_confirmpassw2 = QtWidgets.QLineEdit(settingsUI)
        self.le_confirmpassw2.setGeometry(QtCore.QRect(570, 440, 191, 31))
        self.le_confirmpassw2.setEchoMode(QtWidgets.QLineEdit.Password)
        self.le_confirmpassw2.setObjectName("le_confirmpassw2")
        self.lbl_confirmpassw2 = QtWidgets.QLabel(settingsUI)
        self.lbl_confirmpassw2.setGeometry(QtCore.QRect(480, 440, 91, 31))
        font = QtGui.QFont()
        font.setFamily("Sylfaen")
        font.setPointSize(10)
        self.lbl_confirmpassw2.setFont(font)
        self.lbl_confirmpassw2.setStyleSheet("""
        #lbl_confirmpassw2 {
        background-color: #FFFFFF;
        color: #333333;
        font-size: 10px;        /* Smaller font to fit text */
        border-radius: 4px;
        padding: 2px;
        }
        """)
        self.lbl_confirmpassw2.setObjectName("lbl_confirmpassw2")
        self.label = QtWidgets.QLabel(settingsUI)
        self.label.setGeometry(QtCore.QRect(340, 150, 121, 131))
        self.label.setText("")

        # self.label.setPixmap(QtGui.QPixmap("defaultpfp.PNG"))
        self.label.setStyleSheet("""
                    QLabel {
                        border-image: url(:/images/defaultpfp.PNG);
                    }
                """)

        self.label.setScaledContents(True)
        self.label.setObjectName("label")

        self.btn_changeavatar = QtWidgets.QPushButton(settingsUI)
        self.btn_changeavatar.setGeometry(QtCore.QRect(340, 285, 121, 31))
        font = QtGui.QFont()
        font.setFamily("Sylfaen")
        font.setPointSize(12)
        self.btn_changeavatar.setFont(font)
        self.btn_changeavatar.setObjectName("btn_changeavatar")

        self.btn_changeuser = QtWidgets.QPushButton(settingsUI)
        self.btn_changeuser.setGeometry(QtCore.QRect(640, 170, 121, 31))
        font = QtGui.QFont()
        font.setFamily("Sylfaen")
        font.setPointSize(12)
        self.btn_changeuser.setFont(font)
        self.btn_changeuser.setObjectName("btn_changeuser")
        self.btn_changepassw = QtWidgets.QPushButton(settingsUI)
        self.btn_changepassw.setGeometry(QtCore.QRect(640, 320, 121, 31))
        font = QtGui.QFont()
        font.setFamily("Sylfaen")
        font.setPointSize(12)
        self.btn_changepassw.setFont(font)
        self.btn_changepassw.setObjectName("btn_changepassw")
        self.btn_exit = QtWidgets.QPushButton(settingsUI)
        self.btn_exit.setGeometry(QtCore.QRect(560, 580, 131, 31))
        font = QtGui.QFont()
        font.setFamily("Sylfaen")
        font.setPointSize(12)

        self.btn_exit.setFont(font)
        self.btn_exit.setObjectName("btn_exit")

        self.lbl_changeemail = QtWidgets.QLabel(settingsUI)
        self.lbl_changeemail.setGeometry(QtCore.QRect(800, 210, 91, 31))
        font = QtGui.QFont()
        font.setFamily("Sylfaen")
        font.setPointSize(10)
        self.lbl_changeemail.setFont(font)
        self.lbl_changeemail.setStyleSheet("""
        #lbl_changeemail {
        background-color: #FFFFFF;
        color: #333333;
        font-size: 10px;        /* Smaller font to fit text */
        border-radius: 4px;
        padding: 2px;
        }
        """)
        self.lbl_changeemail.setObjectName("lbl_changeemail")

        self.le_changeemail = QtWidgets.QLineEdit(settingsUI)
        self.le_changeemail.setGeometry(QtCore.QRect(900, 210, 191, 31))
        self.le_changeemail.setObjectName("le_changeemail")

        self.lbl_emailpassw = QtWidgets.QLabel(settingsUI)
        self.lbl_emailpassw.setGeometry(QtCore.QRect(800, 250, 91, 31))
        self.lbl_emailpassw.setFont(font)
        self.lbl_emailpassw.setStyleSheet("""
        #lbl_emailpassw {
        background-color: #FFFFFF;
        color: #333333;
        font-size: 10px;        /* Smaller font to fit text */
        border-radius: 4px;
        padding: 2px;
        }
        """)
        self.lbl_emailpassw.setObjectName("lbl_emailpassw")

        self.le_emailpassw = QtWidgets.QLineEdit(settingsUI)
        self.le_emailpassw.setGeometry(QtCore.QRect(900, 250, 191, 31))
        self.le_emailpassw.setEchoMode(QtWidgets.QLineEdit.Password)
        self.le_emailpassw.setObjectName("le_emailpassw")

        self.btn_changeemail = QtWidgets.QPushButton(settingsUI)
        self.btn_changeemail.setGeometry(QtCore.QRect(970, 290, 121, 31))
        font12 = QtGui.QFont()
        font12.setFamily("Sylfaen")
        font12.setPointSize(12)
        self.btn_changeemail.setFont(font12)
        self.btn_changeemail.setObjectName("btn_changeemail")

        self.retranslateUi(settingsUI)
        QtCore.QMetaObject.connectSlotsByName(settingsUI)

    def retranslateUi(self, settingsUI):
        _translate = QtCore.QCoreApplication.translate
        settingsUI.setWindowTitle(_translate("settingsUI", "Form"))
        self.lbl_user.setText(_translate("settingsUI", " USERNAME"))
        self.lbl_changeuser.setText(_translate("settingsUI", "Change User"))
        self.lbl_confirmpassw.setText(_translate("settingsUI", "Confirm Pass"))
        self.lbl_passw.setText(_translate("settingsUI", "PASSWORD"))
        self.lbl_newpassw.setText(_translate("settingsUI", "New Pass"))
        self.lbl_currentpassw.setText(_translate("settingsUI", "Current Pass"))
        self.lbl_confirmpassw2.setText(_translate("settingsUI", "Confirm Pass"))
        self.btn_changeavatar.setText(_translate("settingsUI", "Change Avatar"))
        self.btn_changeuser.setText(_translate("settingsUI", "Confirm Change"))
        self.btn_changepassw.setText(_translate("settingsUI", "Confirm Change"))
        self.btn_changeemail.setText(_translate("settingsUI", "Confirm Change"))
        self.lbl_changeemail.setText(_translate("settingsUI", "New Email"))
        self.lbl_emailpassw.setText(_translate("settingsUI", "Confirm Pass"))
        self.btn_exit.setText(_translate("settingsUI", "Exit"))


if __name__ == "__main__":
    import sys

    app = QtWidgets.QApplication(sys.argv)
    settingsUI = QtWidgets.QWidget()
    ui = Ui_settingsUI()
    ui.setupUi(settingsUI)
    settingsUI.show()
    sys.exit(app.exec_())
