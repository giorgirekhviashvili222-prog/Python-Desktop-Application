import os.path
from icoextract import IconExtractor
from PyQt5.QtWidgets import QApplication, QFileDialog
from databases import GameDatabase

game_loaded = None


# tamashis klasi, romelsac moaqvs saxeli da misamarti
class GameData:
    def __init__(self, gname, gpath, game_icon_path):
        self.gname = gname
        self.gpath = gpath
        self.game_icon_path = game_icon_path


# funqccia romelic igebs failis paths
def get_file_path():
    file_path, _ = QFileDialog.getOpenFileName(
        None, "Select Your Game File", "", "Executable Files (*.exe);;All Files (*)"
    )

    return file_path


def get_game_icon(exe_path, game_name, output_folder="game_icons"):
    """Extracts the main icon from an .exe file and returns its path."""
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    ico_path = os.path.join(output_folder, f"{game_name}.ico")

    if os.path.exists(ico_path):
        return ico_path
    try:
        # Extract the highest resolution icon resource
        extractor = IconExtractor(exe_path)
        extractor.export_icon(ico_path)
        return ico_path
    except Exception as e:
        print(f"Could not extract icon from {exe_path}: {e}")
        return None


# funqcia romelic amatebs tamahs monacemta bazashi
""" აქაც category ჩავამატე """


def selection(user_id, category_name="All Categories"):
    from mainmenu import MainMenu

    path = get_file_path()

    print(path)

    if path:
        gname = str(
            os.path.basename(os.path.dirname(path))
        )  # failis misamartidan igebs saxels

        icon = get_game_icon(path, gname)
        print(icon)

        game = GameData(gname, path, icon)

        db = GameDatabase()
        db.insert_game(user_id, game.gname, game.gpath, icon, category_name)
        added_one = MainMenu(user_id)
        added_one.games_libarary()

        # latest_game  = MainMenu(user_id)
        # latest_game.add_certain_game()

        print("File is uploaded")
        return True
    else:
        print("No file selected")
        return False
