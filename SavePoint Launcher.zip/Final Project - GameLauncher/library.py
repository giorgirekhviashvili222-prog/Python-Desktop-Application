from PyQt5 import QtCore, QtGui, QtWidgets
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

from PyQt5.QtCore import Qt


class Ui_centralWidget(object):
    def setupUi(self, centralWidget):
        centralWidget.setObjectName("centralWidget")
        centralWidget.resize(1280, 780)
        centralWidget.setMinimumSize(QtCore.QSize(1280, 780))
        centralWidget.setMaximumSize(QtCore.QSize(1280, 780))

        self.centralwidget = QtWidgets.QWidget(centralWidget)
        self.centralwidget.setObjectName("centralwidget")

        self.launcherlogo = QtWidgets.QLabel(self.centralwidget)
        self.launcherlogo.setGeometry(QtCore.QRect(20, 20, 80, 80))
        self.launcherlogo.setStyleSheet(
            "background-color: #2a475e; border-radius: 40px;"
        )
        self.launcherlogo.setObjectName("launcherlogo")
        self.pixmap = QtGui.QPixmap("savepointe.png")
        self.pixmap = self.pixmap.scaled(
            80, 80, QtCore.Qt.KeepAspectRatio, QtCore.Qt.SmoothTransformation
        )
        self.launcherlogo.setPixmap(self.pixmap)
        self.launcherlogo.setAlignment(QtCore.Qt.AlignCenter)

        self.launchername = QtWidgets.QLabel(self.centralwidget)
        self.launchername.setGeometry(QtCore.QRect(120, 40, 250, 41))
        font = QtGui.QFont("Segoe UI", 24, QtGui.QFont.Bold)
        self.launchername.setFont(font)
        self.launchername.setStyleSheet("color: #ffffff;")
        self.launchername.setObjectName("launchername")

        self.lblavatar = QtWidgets.QLabel(self.centralwidget)
        self.lblavatar.setGeometry(QtCore.QRect(1160, 20, 80, 80))
        self.lblavatar.setStyleSheet("""
            QLabel {
                background-color: #10141b;
                border: 2px solid #3d4450;
                border-radius: 40px;
            }
        """)
        self.lblavatar.setScaledContents(True)
        self.lblavatar.setObjectName("lblavatar")

        self.lblusername = QtWidgets.QLabel(self.centralwidget)
        self.lblusername.setGeometry(QtCore.QRect(920, 25, 220, 31))
        font = QtGui.QFont("Segoe UI", 14, QtGui.QFont.Bold)
        self.lblusername.setFont(font)
        self.lblusername.setStyleSheet("color: #66c0f4;")
        self.lblusername.setAlignment(
            QtCore.Qt.AlignRight | QtCore.Qt.AlignTrailing | QtCore.Qt.AlignVCenter
        )
        self.lblusername.setObjectName("lblusername")

        self.btn_settings = QtWidgets.QPushButton(self.centralwidget)
        self.btn_settings.setGeometry(QtCore.QRect(950, 65, 100, 35))
        self.btn_settings.setObjectName("btn_settings")

        self.btn_logout = QtWidgets.QPushButton(self.centralwidget)
        self.btn_logout.setGeometry(QtCore.QRect(1060, 65, 100, 35))
        self.btn_logout.setObjectName("btn_logout")

        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(20, 120, 251, 31))
        font = QtGui.QFont("Segoe UI", 12, QtGui.QFont.Bold)
        self.label.setFont(font)
        self.label.setStyleSheet("color: #66c0f4;")
        self.label.setObjectName("label")

        self.listWidget = QtWidgets.QListWidget(self.centralwidget)
        self.listWidget.setGeometry(QtCore.QRect(20, 155, 250, 130))
        self.listWidget.setObjectName("listWidget")

        self.btn_addcategory = QtWidgets.QPushButton(self.centralwidget)
        self.btn_addcategory.setGeometry(QtCore.QRect(20, 295, 250, 35))
        self.btn_addcategory.setObjectName("btn_addcategory")

        self.listWidget_2 = QtWidgets.QListWidget(self.centralwidget)
        self.listWidget_2.setGeometry(QtCore.QRect(20, 345, 250, 335))
        self.listWidget_2.setObjectName("listWidget_2")

        self.btn_addgame = QtWidgets.QPushButton(self.centralwidget)
        self.btn_addgame.setGeometry(QtCore.QRect(20, 690, 250, 40))
        self.btn_addgame.setObjectName("btn_addgame")

        self.setupRightPanel(centralWidget)

        centralWidget.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(centralWidget)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 1280, 21))
        self.menubar.setObjectName("menubar")
        centralWidget.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(centralWidget)
        self.statusbar.setObjectName("statusbar")
        centralWidget.setStatusBar(self.statusbar)

        self.retranslateUi(centralWidget)
        QtCore.QMetaObject.connectSlotsByName(centralWidget)

    def retranslateUi(self, centralWidget):
        _translate = QtCore.QCoreApplication.translate
        centralWidget.setWindowTitle(_translate("centralWidget", "SavePoint"))
        self.launchername.setText(_translate("centralWidget", "SavePoint"))
        self.lblusername.setText(_translate("centralWidget", "USERNAME"))
        self.btn_settings.setText(_translate("centralWidget", "Settings"))
        self.btn_logout.setText(_translate("centralWidget", "Log Out"))
        self.label.setText(_translate("centralWidget", "LIBRARY CATEGORIES"))
        self.btn_addcategory.setText(_translate("centralWidget", "Add Category"))
        self.btn_addgame.setText(_translate("centralWidget", "Add Game"))

    def setupRightPanel(self, centralWidget):
        # es sheicvala ########################
        self.lbl_coverart = QtWidgets.QLabel(self.centralwidget)
        self.lbl_coverart.setGeometry(QtCore.QRect(320, 180, 340, 340))

        self.lbl_coverart.setScaledContents(False)
        self.lbl_coverart.setAlignment(QtCore.Qt.AlignCenter)

        self.lbl_coverart.setStyleSheet("""
            QLabel {
                border: 2px dashed #3d4450;
                border-radius: 8px;
                background-color: #10141b;
            }
        """)
        self.lbl_coverart.setText("")
        self.lbl_coverart.setObjectName("lbl_coverart")
        #####################

        ###################
        self.lbl_gamename = QtWidgets.QLabel(self.centralwidget)
        self.lbl_gamename.setGeometry(QtCore.QRect(695, 180, 600, 50))
        self.lbl_gamename.setStyleSheet(
            "color: #ffffff; font-size: 32px; font-weight: bold; font-family: 'Segoe UI';"
        )
        self.lbl_gamename.setText("Game Title Placeholder")
        self.lbl_gamename.setObjectName("lbl_gamename")

        self.lbl_release = QtWidgets.QLabel(self.centralwidget)
        self.lbl_release.setGeometry(QtCore.QRect(700, 240, 450, 31))
        self.lbl_release.setStyleSheet("color: #b0bec5; font-size: 16px;")
        self.lbl_release.setText("Ready to Play")
        self.lbl_release.setObjectName("lbl_release")

        self.lbl_developer = QtWidgets.QLabel(self.centralwidget)
        self.lbl_developer.setGeometry(QtCore.QRect(700, 280, 450, 31))
        self.lbl_developer.setStyleSheet(
            "color: #66c0f4; font-size: 16px; font-weight: bold;"
        )
        self.lbl_developer.setText("Total playtime: 0")
        self.lbl_developer.setObjectName("lbl_developer")

        # achivments
        self.lbl_achv = QtWidgets.QLabel(self.centralwidget)
        self.lbl_achv.setGeometry(QtCore.QRect(700, 320, 450, 31))
        self.lbl_achv.setStyleSheet(
            "color: #66c0f4; font-size: 16px; font-weight: bold;"
        )
        self.lbl_achv.setText("Current Achievement: None")
        self.lbl_achv.setObjectName("lbl_achv")
        ##

        self.btn_play = QtWidgets.QLabel(self.centralwidget)
        self.btn_play.setGeometry(QtCore.QRect(920, 660, 260, 60))
        self.btn_play.setScaledContents(True)
        self.btn_play.setStyleSheet("""
            QLabel {
                background-color: #5c7e10; 
                color: white;
                font-size: 24px;
                font-family: 'Segoe UI';
                font-weight: bold;
                border-radius: 6px;
                qproperty-alignment: AlignCenter;
            }
            QLabel:hover {
                background-color: #739c14;
            }
        """)
        self.btn_play.setText("PLAY")
        self.btn_play.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.btn_play.setObjectName("btn_play")
        ##########################################

    def charts_UI(self, visible=False):
        if not hasattr(self, "canvas"):
            self.chart_fig = Figure(figsize=(3, 3))
            self.canvas = FigureCanvas(self.chart_fig)
            self.canvas.setParent(self.centralwidget)
            self.canvas.setGeometry(250, 100, 600, 500)  # Adjust if needed
            self.canvas.setStyleSheet("background-color: transparent;")

            self.game_lst = QtWidgets.QListWidget(self.centralwidget)
            self.game_lst.setGeometry(QtCore.QRect(850, 210, 270, 430))
            self.game_lst.setObjectName("listWidget")

        if visible:
            self.canvas.show()
            self.game_lst.show()
        else:
            self.canvas.hide()
            self.game_lst.hide()
        print(visible)

    def setRightPanelVisible(self, visible=True):
        widgets = [
            self.lbl_coverart,
            self.lbl_gamename,
            self.lbl_release,
            self.lbl_developer,
            self.btn_play,
            self.lbl_achv,  ##es chaemata
        ]
        for widget in widgets:
            if hasattr(self, widget.objectName()):
                if visible:
                    widget.show()
                else:
                    widget.hide()


if __name__ == "__main__":
    import sys

    app = QtWidgets.QApplication(sys.argv)
    centralWidget = QtWidgets.QMainWindow()
    ui = Ui_centralWidget()
    ui.setupUi(centralWidget)
    centralWidget.show()
    sys.exit(app.exec_())
