import resources
from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_TheBackground(object):
    def setupUi(self, TheBackground):
        TheBackground.setObjectName("TheBackground")
        TheBackground.resize(1110, 670)

        # Logo placeholder (Kept your dimensions, removed image hardcoding for safety, but you can re-add the pixmap if you have a transparent logo)
        self.logo = QtWidgets.QLabel(TheBackground)
        self.logo.setGeometry(QtCore.QRect(360, 100, 141, 121))
        self.logo.setObjectName("logo")

        self.logo2 = QtWidgets.QLabel(TheBackground)
        self.logo2.setGeometry(QtCore.QRect(510, 130, 281, 61))
        self.logo2.setObjectName("logo2")
        self.logo2.setText("SavePoint")
        font = QtGui.QFont("Segoe UI", 24, QtGui.QFont.Bold)
        self.logo2.setFont(font)

        # Inputs
        self.username_field = QtWidgets.QLineEdit(TheBackground)
        self.username_field.setGeometry(QtCore.QRect(410, 260, 291, 40))
        self.username_field.setObjectName("username_field")
        self.username_field.setPlaceholderText("Enter Username")

        self.email_field = QtWidgets.QLineEdit(TheBackground)
        self.email_field.setGeometry(QtCore.QRect(410, 310, 291, 40))
        self.email_field.setObjectName("email_field")
        self.email_field.setPlaceholderText("Enter Email")

        self.password_field = QtWidgets.QLineEdit(TheBackground)
        self.password_field.setGeometry(QtCore.QRect(410, 360, 291, 40))
        self.password_field.setEchoMode(QtWidgets.QLineEdit.Password)
        self.password_field.setObjectName("password_field")
        self.password_field.setPlaceholderText("Enter Password")

        # Buttons - Stripped image URLs so QSS can style them cleanly
        self.register_button = QtWidgets.QPushButton(TheBackground)
        self.register_button.setGeometry(QtCore.QRect(405, 420, 300, 45))
        self.register_button.setObjectName("register_button")

        self.log_in_button = QtWidgets.QPushButton(TheBackground)
        self.log_in_button.setGeometry(QtCore.QRect(405, 480, 300, 45))
        self.log_in_button.setObjectName("log_in_button")

        # Labels
        self.label = QtWidgets.QLabel(TheBackground)
        self.label.setGeometry(QtCore.QRect(310, 265, 91, 31))
        self.label.setObjectName("label")

        self.label_email = QtWidgets.QLabel(TheBackground)
        self.label_email.setGeometry(QtCore.QRect(310, 315, 91, 31))
        self.label_email.setObjectName("label_email")

        self.label_2 = QtWidgets.QLabel(TheBackground)
        self.label_2.setGeometry(QtCore.QRect(310, 365, 91, 31))
        self.label_2.setObjectName("label_2")

        self.retranslateUi(TheBackground)
        QtCore.QMetaObject.connectSlotsByName(TheBackground)

    def retranslateUi(self, TheBackground):
        _translate = QtCore.QCoreApplication.translate
        TheBackground.setWindowTitle(_translate("TheBackground", "Login to SSteam"))
        self.label.setText(_translate("TheBackground", "Username:"))
        self.label_email.setText(_translate("TheBackground", "Email:"))
        self.label_2.setText(_translate("TheBackground", "Password:"))
        self.register_button.setText(_translate("TheBackground", "CREATE ACCOUNT"))
        self.log_in_button.setText(_translate("TheBackground", "LOGIN"))
