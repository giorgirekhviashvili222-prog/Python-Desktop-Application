import sqlite3
import sys
from PyQt5 import QtWidgets, QtCore, QtGui
from library import Ui_centralWidget
from browse import selection


class MainMenu(QtWidgets.QMainWindow, Ui_centralWidget):
    def __init__(self, user_id, dbname="games.db"):
        super().__init__()
        self.setupUi(self)
        self.user_id = user_id

        self.d = "aaaa@gmail.com"
        print(self.d[-10:])

        self.achivment_names = {60:"Welcome to new world", 300:"Do you like here?", 600:"Actually yes", 1800:"Explorer",
                                3600:"Do you make your homework?", 7200:"No Refunds", 18000:"Go touch a grass",
                                36000:"Go find a job lil bro"
                                }
        #1min - 5min - 10min - 30min - 1 hour - 2 hour - 5 hour - 10hour

        self.conn = sqlite3.connect(dbname)
        self.conn.row_factory = sqlite3.Row
        self.cursor = self.conn.cursor()

        ################################
        self.default_checker()
        ################################
        self.load_categories()

        # ეს კატეგორიაზე დაკლიკებისას იძახებს on_category_select ფუნქციას
        self.listWidget.itemClicked.connect(self.on_category_select)

        self.btn_addcategory.clicked.connect(self.add_new_category)

        # xsnis browse windows
        self.btn_addgame.clicked.connect(self.browse_window)
        self.add_game_window = None

        # usernameis ganaxleba titoeuli useristvis
        self.user_name = self.set_user_name()
        if self.user_name:
            self.lblusername.setText(self.user_name)
        else:
            self.lblusername.setText("Unknow user")

        # iconis dayeneba
        self.set_user_icon()
        print(self.set_user_icon())

        ######################################
        print(self.set_user_name())
        print(f"Successfully entered Main Menu for User ID: {self.user_id}")
        # print(f"Games list: {self.games}")

        # logOut - gasvlis gilaki
        self.btn_logout.clicked.connect(self.log_out)
        self.logout = None
        self.log_in_window = None

        # remove game window, when u click right click on mouse
        self.listWidget_2.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.listWidget_2.customContextMenuRequested.connect(self.open_right_click_menu)

        self.listWidget_2.itemClicked.connect(self.display_game_details)

        self.btn_settings.clicked.connect(self.enter_settings)

        self.btn_play.installEventFilter(self)
        #Play_time
        self.playtime = None

        #Charts

    # browse funqciis gamosadzaxeblad
    def browse_window(self):
        # 1. Figure out which category is currently clicked in the UI
        current_category = "All Categories"
        if self.listWidget.currentItem():
            current_category = self.listWidget.currentItem().text()

        # 2. Pass that category into the selection function
        if selection(self.user_id, current_category):

            # 3. Refresh the games list to show the new game in the correct category
            self.listWidget_2.clear()
            game_query = """
                         SELECT game_name
                         FROM games
                         WHERE user_id = ? AND category = ?
                         """
            game_data = self.cursor.execute(
                game_query, (self.user_id, current_category)
            ).fetchall()
            for row in game_data:
                self.listWidget_2.addItem(row["game_name"])

    def open_right_click_menu(self, position):
        selected_item = self.listWidget_2.itemAt(position)

        if not selected_item:
            return
        # menus sheqmna
        context_menu = QtWidgets.QMenu(self)

        # warweris damateba, romelic amovardeba click is mere
        remove_action = context_menu.addAction("Remove game from library")

        action = context_menu.exec_(self.listWidget_2.mapToGlobal(position))

        if action == remove_action:
            self.game_removal_system(selected_item)

    def game_removal_system(self, item):
        game_name = item.text()

        confirm = QtWidgets.QMessageBox.question(
            self,
            "Remove Game",
            f"Are you sure you want to remove '{game_name}' from your library?",
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
        )

        if confirm == QtWidgets.QMessageBox.Yes:
            try:

                delete_query = "DELETE FROM games WHERE user_id = ? AND game_name = ?"
                self.cursor.execute(delete_query, (self.user_id, game_name))
                self.conn.commit()

                self.listWidget_2.takeItem(self.listWidget_2.row(item))

                print(f"Removed {game_name} from database and UI successfully.")

            except Exception as e:
                QtWidgets.QMessageBox.critical(
                    self, "Error", f"Could not remove game: {e}"
                )
    def time_converner(self, seconds):
        sec = "00"
        min = "00"
        hour = "00"
        s = seconds % 60
        if len(str(s)) == 1:
            sec = f"0{s}"
        else:
            sec = f"{s}"

        if seconds > 59:
            m = seconds // 60
            if len(str(m)) == 1:
                min = f"0{m}"
            else:
                min = f"{m}"
            if m > 59:
                h = m // 60
                if len(str(h)) == 1:
                    hour = f"0{h}"
                else:
                    hour = f"{h}"

        entire_time = f"{hour}:{min}:{sec}"
        return entire_time


    # tamashze dawerisas amodis misi info (iconi, play button  da monacemebi)
    def display_game_details(self, item):
        game_name = item.text()

        self.charts_UI(False)
        self.lbl_gamename.setText(game_name)
        query = """
                SELECT icon_path, play_time FROM games WHERE game_name = ? and user_id = ?
                """
        game_data = self.cursor.execute(query, (game_name, self.user_id)).fetchall()
        game_dict = [dict(i) for i in game_data]

        icon_path = QtGui.QPixmap(game_dict[0]["icon_path"])
        seconds = game_dict[0]["play_time"] # -->>INT

        entire_time = self.time_converner(seconds) #wamebi gayavs adamianebistvis agsaqmel droshi 00:00:00

        if not icon_path.isNull():
            self.lbl_coverart.setPixmap(icon_path)
        else:
            self.lbl_coverart.clear()
            self.lbl_coverart.setText("No Cover Art")

        self.lbl_developer.setText(f"Total playtime: {entire_time}")

        #achievements
        new_achievement = None
        for i in range(len(self.achivment_names)):
            if seconds > list(self.achivment_names.keys())[i]:
                print(list(self.achivment_names.values())[i])
                new_achievement = list(self.achivment_names.values())[i]
            else:
                break

        achv_update ="UPDATE games SET achievement = ? WHERE user_id = ? AND game_name = ?"
        self.cursor.execute(achv_update, (new_achievement, self.user_id, game_name))
        self.conn.commit()

        achv_query = "SELECT achievement FROM games WHERE game_name = ? AND user_id = ?"
        achv_data = self.cursor.execute(achv_query, (game_name, self.user_id)).fetchone()
        if achv_data:
            achv = achv_data[0]
            self.lbl_achv.setText(f"Current Achievement: {achv}")
            print(achv)
        else:
            achv = "None"
            print(achv)

        self.setRightPanelVisible(True)

    # igebs useris saxels da awers username charchoshi
    def set_user_name(self):
        conn2 = sqlite3.connect("users.db")
        conn2.row_factory = sqlite3.Row
        cursor2 = conn2.cursor()

        username_query = """
                            SELECT DISTINCT name 
                            FROM user
                            WHERE id = ?
                        """
        cursor2.execute(username_query, (self.user_id,))
        name = cursor2.fetchone()
        return name["name"]

    def set_user_icon(self):
        conn2 = sqlite3.connect("users.db")
        conn2.row_factory = sqlite3.Row
        cursor2 = conn2.cursor()

        icon_query = """
                         SELECT DISTINCT pfp_path
                         FROM user
                         WHERE id = ? \
                         """
        cursor2.execute(icon_query, (self.user_id,))
        icon_path = cursor2.fetchone()
        clean_path = icon_path["pfp_path"].replace("\\", "/")
        self.lblavatar.setStyleSheet(f"""
            QLabel {{
                border-image: url("{clean_path}");
            }}
        """)
        return True

    # tamashebis chamonatvali titoeli useristvis gansxvavebuli
    def games_libarary(self):
        try:
            game_query = """
                         SELECT game_name, game_path 
                         FROM games
                         WHERE user_id = ? 
                         """

            game_data = self.cursor.execute(game_query, (self.user_id,)).fetchall()
            game_dict = [dict(i) for i in game_data]

            return game_dict
        except sqlite3.OperationalError as e:
            print(f"Database error (Does the 'games' table exist?): {e}")
            return []

    # accaountis datoveba
    def log_out(self):
        from main import Registration

        if self.logout is None:
            self.log_in_window = Registration()
            self.log_in_window.show()
            self.hide()
            self.conn.close()

    def enter_settings(self):
        from settingsmenu import Changer

        conn = sqlite3.connect("users.db")
        cursor = conn.cursor()
        cursor.execute("SELECT name FROM user WHERE id = ?", (self.user_id,))
        logged_in_user = cursor.fetchone()[0]
        conn.close()

        self.hide()

        self.settings_win = Changer(logged_in_user)

        self.settings_win.main_menu = self
        self.settings_win.show()

    def update_profile_ui(self):
        # Refresh the username text from the current state
        self.user_name = self.set_user_name()
        if self.user_name:
            self.lblusername.setText(self.user_name)
        else:
            self.lblusername.setText("Unknown user")

        # Reload the avatar style sheet
        self.set_user_icon()

    def game_runner(self):
        import os
        import subprocess #tamashis chartva/gatishvis drois chasanishnad
        from datetime import datetime

        selected_game = self.listWidget_2.currentItem()
        game_name = selected_game.text()

        if not selected_game:
            QtWidgets.QMessageBox.warning(
                self, "Warning", "Please select a game from the list first!"
            )
            return

        game_path_query = """
                        SELECT game_path FROM games
                        WHERE game_name = ? AND user_id = ?
                        """

        game_path = self.cursor.execute(
            game_path_query, (game_name, self.user_id)
        ).fetchone()

        if game_path and game_path["game_path"]:
            old_path = game_path["game_path"]
            clean_path = os.path.abspath(old_path.replace("/", "\\"))

            game_directory = os.path.dirname(clean_path)


            command = None
            if os.path.exists(clean_path):
                print(f"Opening: {clean_path}")
                #drois atvla

                if clean_path.endswith('.py'):

                    command = [sys.executable, clean_path]#rtavs pythonis kods, dagvwirda deffault tammashebis gasashvebad
                elif clean_path.endswith('.exe'):

                    command = [clean_path] #amowmebs tu exe failia amas gaushvebs
                else:
                    print("Unsupported file type!")

                start_time = datetime.now()
                print(start_time)
                #gashveba
                process = subprocess.Popen(command, cwd=game_directory)

                # elodeba, sanam tamashi gashvebulia danarcheni kodi ar funqcionirebs, mxolod gatushivs mere iwyeba moqmedeba
                process.wait()
                #dasruleba
                end_time = datetime.now()
                print(end_time)

                self.playtime = int((end_time - start_time).total_seconds())
                print(self.playtime)
                self.save_playtime(game_name)

            else:
                QtWidgets.QMessageBox.critical(
                self, "Error", f"Could not find the game file at:\n{clean_path}"
                )
        else:
            QtWidgets.QMessageBox.critical(
                self, "Error", "Game path not found in database."
            )


    def eventFilter(self, obj, event):
        # Check if the event happened on your play label and if it was a mouse press
        if obj == self.btn_play and event.type() == QtCore.QEvent.MouseButtonPress:
            if event.button() == QtCore.Qt.LeftButton:
                self.game_runner()
                return True
        return super().eventFilter(obj, event)

    def default_checker(self):
        default_checker_query = """
                                SELECT COUNT(*) FROM games 
                                WHERE user_id = ? AND game_name LIKE 'Default_%'
                                """
        self.cursor.execute(default_checker_query, (self.user_id,))
        count = self.cursor.fetchone()[0]


        if count == 0:
            print(f"No default games found for User {self.user_id}. Generating them...")
            self.default_games()
            return True
        return False

    def load_categories(self):
        # ბაზიდან მოაქვს მომხმარებლის კატეგორიები და გამოაქვს ეკრანზე
        self.listWidget.clear()

        try:
            query = "SELECT DISTINCT category FROM games WHERE user_id = ?"
            categories_data = self.cursor.execute(query, (self.user_id,)).fetchall()

            categories = [row["category"] for row in categories_data]

            if "All Categories" not in categories:
                categories.insert(0, "All Categories")

            for cat in categories:
                self.listWidget.addItem(cat)

            if self.listWidget.count() > 0:
                self.listWidget.setCurrentRow(0)
                self.on_category_select(self.listWidget.item(0))

        except sqlite3.OperationalError as e:
            print(f"{e}")

    def on_category_select(self, item):
        # კატეგორიის არჩევისას გამოაქვს მხოლოდ ამ კატეგორიის თამაშები
        category_name = item.text()
        self.listWidget_2.clear()
        self.setRightPanelVisible(False)
        self.charts_UI(True)

        self.game_statistic_data(category_name)

        if category_name == "All Categories":
            games = self.games_libarary()
            self.charts_UI(True)
            # self.charts()

            for game in games:
                self.listWidget_2.addItem(game["game_name"])

        else:

            try:
                query = "SELECT game_name FROM games WHERE user_id = ? AND category = ?"
                games_data = self.cursor.execute(
                    query, (self.user_id, category_name)
                ).fetchall()

                for row in games_data:
                    self.listWidget_2.addItem(row["game_name"])

            except sqlite3.OperationalError as e:
                print(f"{e}")

    def add_new_category(self):
        # ხსნის ფანჯარას ახალი კატეგორიის დასამატებლად
        text, ok = QtWidgets.QInputDialog.getText(
            self, "Add Category", "Enter new category:"
        )

        if ok and text:
            existing_items = [
                self.listWidget.item(i).text() for i in range(self.listWidget.count())
            ]
            if text in existing_items:
                QtWidgets.QMessageBox.warning(
                    self, "Warning", "Category already exists"
                )
                return

            self.listWidget.addItem(text)

    def default_games(self):
        snake = (self.user_id, "Default_Snake", "default_games/snake.py", "default_game_icons\\snake.ico", 0,"Default",)
        self.cursor.execute(
            """
                       INSERT INTO games(user_id, game_name, game_path, icon_path, play_time, category)
                       VALUES (?, ?, ?, ?, ?, ?)
                       """,snake)

        flappy = ( self.user_id, "Default_Flappy", "default_games/flappy.py", "default_game_icons\\flappy.ico", 0, "Default", )
        self.cursor.execute(
            """
                            INSERT INTO games(user_id, game_name, game_path, icon_path, play_time, category)
                            VALUES (?, ?, ?, ?, ?, ?)
                            """, flappy,)

        sudoku = (self.user_id, "Default_Sudoku", "default_games/sudoku.py", "default_game_icons\\sudoku.ico", 0, "Default",)
        self.cursor.execute(
            """
                INSERT INTO games(user_id, game_name, game_path, icon_path, play_time, category)
                VALUES (?, ?, ?, ?, ?, ?)
                """,sudoku,)

        self.conn.commit()

    def save_playtime(self, gname):
        print(self.playtime, gname, self.user_id)
        sql_query = "UPDATE games SET play_time = play_time + ? WHERE user_id = ? and game_name = ?"

        self.cursor.execute(sql_query, (self.playtime, self.user_id, gname))
        self.conn.commit()

    def game_statistic_data(self, category_name):
        try:
            if category_name == "All Categories": #gamoitans yvela kategoriidan monacemebs
                gname_playtime_query = """
                                       SELECT game_name, play_time \
                                       FROM games
                                       WHERE user_id = ? \
                                       ORDER BY play_time DESC \
                                       """
                data = self.cursor.execute(gname_playtime_query, (self.user_id,)).fetchall()
            else: #gamoitans konkretuli kategoriidan monacemebs
                gname_playtime_query = """
                                        SELECT game_name, play_time FROM games
                                        WHERE user_id = ? AND category = ?
                                        ORDER BY play_time DESC 
                                        """
                data = self.cursor.execute(gname_playtime_query, (self.user_id,category_name)).fetchall()

            games_stats = dict(data)
            self.charts(games_stats)
            return games_stats

        except Exception as e:
            print(f"An unexpected error occurred: {e}")


    def charts(self, full_data):
        import matplotlib.pyplot as plt
        import numpy as np

        self.game_lst.clear() #shlis dzvel infos rata axali daematos
        self.chart_fig.clear() #shlis dzvel infos rata axali daematos
        self.chart_fig.patch.set_facecolor('none')

        # Standard subplot works perfectly now because the parent widget is a square
        ax = self.chart_fig.add_subplot(111)
        ax.patch.set_facecolor('none')

        # games_data = self.game_statistic_data()
        games_data = full_data
        print(games_data)

        play_times = list(games_data.values())
        print(list(games_data.keys()))
        print(play_times)

        for i in range(len(play_times)):
            info = f"{i + 1}. {list(games_data.keys())[i]}: {self.time_converner(play_times[i])}"
            self.game_lst.addItem(info)

        if not play_times or sum(play_times) == 0:
            # Draw a beautiful placeholder circle indicating no data
            ax.pie([1], labels=["No Time Logged Yet"], colors=['#d3d3d3'],
                   wedgeprops={"linewidth": 1, "edgecolor": "white"},
                   textprops={'color': 'white', 'fontsize': 11}, startangle=90)
            ax.axis('off')
            self.canvas.draw()
            return

        colors = plt.get_cmap('Greens')(np.linspace(0.5, 0.9, len(play_times)))

        ax.pie(play_times, labels=list(games_data.keys()), autopct='%1.1f%%',
               colors=colors, wedgeprops={"linewidth": 1}, shadow=True, startangle=90,
               textprops={'color': 'white', 'fontsize': 10})
        ax.axis('off')

        self.canvas.draw()

if __name__ == "__main__":
    # Starts the PyQt window engine
    app = QtWidgets.QApplication(sys.argv)

    # Creates the window (Using a dummy user_id of 1 for testing purposes)
    window = MainMenu(user_id=1)
    window.setWindowTitle("SSteam Launcher - Main Menu Testing")

    # Forces the window to pop up on your monitor
    window.show()

    # Keeps the window alive until you click the close (X) button
    sys.exit(app.exec_())
