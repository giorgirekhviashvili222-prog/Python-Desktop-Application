import os
import shutil  # gamoiyeneba copy()stvis
from PyQt5 import QtWidgets, QtGui
from databases import UserDatabase
from settings import Ui_settingsUI
import sqlite3


class Changer(QtWidgets.QWidget):
    def __init__(self, user, parent=None):
        super().__init__(parent)
        self.ui = Ui_settingsUI()
        self.ui.setupUi(self)

        self.setWindowTitle("SavePoint")

        self.user = user
        self.db = UserDatabase()

        self.user_icon = self.set_user_icon()
        if self.user_icon:
            clean_path = self.user_icon.replace("\\", "/")
            self.ui.label.setStyleSheet(f"""
                        QLabel {{
                            border-image: url({clean_path});
                        }}
                    """)

        self.ui.lbl_user.setText(self.user)

        self.ui.btn_changeuser.clicked.connect(self.user_change)
        self.ui.btn_changepassw.clicked.connect(self.pass_change)
        self.ui.btn_changeemail.clicked.connect(self.email_change)
        self.ui.btn_changeavatar.clicked.connect(self.change_avatar)
        self.ui.btn_exit.clicked.connect(self.close)

        self.user_id = self.get_user_id()
        print(self.user_id)

    def paintEvent(self, event):
        opt = QtWidgets.QStyleOption()
        opt.initFrom(self)
        p = QtGui.QPainter(self)
        self.style().drawPrimitive(
            QtWidgets.QStyle.PrimitiveElement.PE_Widget, opt, p, self
        )

    def user_change(self):
        new_user = self.ui.le_changeuser.text().strip()
        passw = self.ui.le_confirmpassw.text().strip()

        if not new_user:
            QtWidgets.QMessageBox.warning(self, "Error", "Please enter a username")
            return
        if not passw:
            QtWidgets.QMessageBox.warning(self, "Error", "Please enter your password")
            return

        good, bad = self.db.change_user(new_user, self.user, passw)
        if good:
            QtWidgets.QMessageBox.information(self, "Success", "User has been changed")
            self.user = new_user
            self.ui.lbl_user.setText(self.user)
            self.ui.le_changeuser.clear()
            self.ui.le_confirmpassw.clear()
        else:
            QtWidgets.QMessageBox.critical(self, "Error", bad)
            self.ui.le_changeuser.clear()
            self.ui.le_confirmpassw.clear()

    def email_change(self):
        new_email = self.ui.le_changeemail.text().strip()
        passw = self.ui.le_emailpassw.text().strip()

        if not new_email or new_email[-10:] != "@gmail.com":
            QtWidgets.QMessageBox.warning(self, "Error", "Please enter a new email")
            return
        if not passw:
            QtWidgets.QMessageBox.warning(self, "Error", "Please enter your password")
            return

        good, bad = self.db.change_email(self.user, passw, new_email)
        if good:
            QtWidgets.QMessageBox.information(self, "Success", "Email has been changed")
            self.ui.le_changeemail.clear()
            self.ui.le_emailpassw.clear()
        else:
            QtWidgets.QMessageBox.critical(self, "Error", bad)
            self.ui.le_changeemail.clear()
            self.ui.le_emailpassw.clear()

    def pass_change(self):
        current = self.ui.le_currentpassw.text().strip()
        new = self.ui.le_newpassw.text().strip()
        conf = self.ui.le_confirmpassw2.text().strip()

        if not all([current, new, conf]):
            QtWidgets.QMessageBox.warning(self, "Error", "Please fill out every field")
            return

        if conf != new:
            QtWidgets.QMessageBox.warning(
                self, "Error", "Please confirm your new password"
            )
            self.ui.le_confirmpassw2.clear()
            return

        good, bad = self.db.change_pass(self.user, current, new)

        if good:
            QtWidgets.QMessageBox.information(
                self, "Success", "Password has been changed"
            )
            self.ui.le_currentpassw.clear()
            self.ui.le_newpassw.clear()
            self.ui.le_confirmpassw2.clear()
        else:
            QtWidgets.QMessageBox.critical(self, "Error", bad)
            self.ui.le_currentpassw.clear()
            self.ui.le_newpassw.clear()
            self.ui.le_confirmpassw2.clear()

    # icon-s amatebs aplikaciashi arsebul iconebis failshi
    def get_avatar_icon(self, icon_path, user_name, output_folder="acc_icons"):
        if not os.path.exists(output_folder):
            os.makedirs(output_folder)

        ico_path = os.path.join(output_folder, f"{user_name}.PNG")
        source_file = icon_path

        try:
            shutil.copy2(source_file, ico_path)
            print(f"Icon successfully saved to: {ico_path}")
            return ico_path
        except FileNotFoundError:
            print(f"Error: The source file at '{source_file}' was not found.")
            return None
        except Exception as e:
            print(f"An error occurred while copying: {e}")
            return None

    def change_avatar(self):
        path, _ = QtWidgets.QFileDialog.getOpenFileName(
            self, "Choose an avatar", "", "Images (*.png *.jpg *.jpeg)"
        )

        if path:
            icon = self.get_avatar_icon(path, self.user)
            self.db.update_avatar(self.user, icon)
            if self.db.update_avatar(self.user, icon):
                self.ui.label.setPixmap(QtGui.QPixmap(icon))
            else:
                QtWidgets.QMessageBox.critical(
                    self, "Error", "Could not save avatar to database."
                )

    def set_user_icon(self):
        conn2 = sqlite3.connect("users.db")
        conn2.row_factory = sqlite3.Row
        cursor2 = conn2.cursor()

        icon_query = """
                            SELECT DISTINCT pfp_path 
                            FROM user
                            WHERE name = ?
                        """
        cursor2.execute(icon_query, (self.user,))
        icon = cursor2.fetchone()

        return icon["pfp_path"]

    def get_user_id(self):
        conn2 = sqlite3.connect("users.db")
        conn2.row_factory = sqlite3.Row
        cursor2 = conn2.cursor()

        id_query = """
                            SELECT DISTINCT id
                            FROM user
                            WHERE name = ?
                        """
        cursor2.execute(id_query, (self.user,))
        usr_id = cursor2.fetchone()

        return usr_id["id"]

    def closeEvent(self, event):
        if hasattr(self, "main_menu") and self.main_menu:
            if hasattr(self.main_menu, "lblusername"):
                self.main_menu.lblusername.setText(self.user)
            self.main_menu.update_profile_ui()
            self.main_menu.show()
        event.accept()
