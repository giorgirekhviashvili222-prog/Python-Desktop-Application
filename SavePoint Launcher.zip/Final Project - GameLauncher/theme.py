MODERN_THEME = """
/* Global Background and Text */
QWidget {
    background-color: #1b2838; /* Steam dark blue/grey */
    color: #c7d5e0;
    font-family: 'Segoe UI', 'Helvetica Neue', sans-serif;
    font-size: 14px;
}

/* Specific background override for main windows if needed */
#TheBackground, #settingsUI, #centralWidget {
    background-color: #171a21; 
}

/* Labels */
QLabel {
    color: #66c0f4; /* Steam light blue accent */
    font-weight: bold;
    background: transparent;
}

/* Input Fields (Usernames, Passwords) */
QLineEdit {
    background-color: #10141b;
    border: 1px solid #3d4450;
    border-radius: 4px;
    padding: 8px;
    color: #ffffff;
}

QLineEdit:focus {
    border: 1px solid #66c0f4;
    background-color: #1a222e;
}

/* Primary Buttons */
QPushButton {
    background-color: #2a475e;
    color: #ffffff;
    border: 1px solid #3d4450;
    border-radius: 4px;
    padding: 8px 16px;
    font-weight: bold;
    font-size: 14px;
}

QPushButton:hover {
    background-color: #66c0f4;
    color: #171a21;
    border: 1px solid #66c0f4;
}

QPushButton:pressed {
    background-color: #4192c0;
}

/* List Widgets (Your Game and Category Lists) */
QListWidget {
    background-color: #10141b;
    border: 1px solid #3d4450;
    border-radius: 4px;
    outline: none;
}

QListWidget::item {
    padding: 10px;
    color: #c7d5e0;
    border-bottom: 1px solid #2a475e;
}

QListWidget::item:hover {
    background-color: #2a475e;
    color: #ffffff;
}

QListWidget::item:selected {
    background-color: #66c0f4;
    color: #171a21;
    font-weight: bold;
}

/* Scrollbars */
QScrollBar:vertical {
    border: none;
    background: #171a21;
    width: 10px;
    margin: 0px 0px 0px 0px;
}
QScrollBar::handle:vertical {
    background: #3d4450;
    min-height: 20px;
    border-radius: 5px;
}
QScrollBar::handle:vertical:hover {
    background: #66c0f4;
}
"""
