import sys
import sqlite3
from PyQt5 import QtWidgets, QtGui
from register2UI import Ui_TheBackground
from databases import UserDatabase, GameDatabase
from mainmenu import MainMenu
from theme import MODERN_THEME


class Registration(QtWidgets.QWidget, Ui_TheBackground):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.db = UserDatabase()
        self.g_db = GameDatabase()

        # amowmebs gilakebs
        self.register_button.clicked.connect(self.handle_registration)
        self.log_in_button.clicked.connect(self.handle_login)

        self.main_menu_window = None

    def paintEvent(self, event):
        opt = QtWidgets.QStyleOption()
        opt.initFrom(self)
        p = QtGui.QPainter(self)
        self.style().drawPrimitive(
            QtWidgets.QStyle.PrimitiveElement.PE_Widget, opt, p, self
        )

    # registaciis funqcia
    def handle_registration(self):
        usr = self.username_field.text().strip()
        eml = self.email_field.text().strip()
        psw = self.password_field.text().strip()

        if not usr or not psw or not eml:
            QtWidgets.QMessageBox.warning(
                self, "Registry Error", "User/Pass fields cannot be empty"
            )
            return
        if eml[-10:] != "@gmail.com":
            QtWidgets.QMessageBox.warning(
                self, "Registry Error", "Invalid email detected. try another one"
            )
            return
        if eml == "":
            QtWidgets.QMessageBox.warning(
                self, "Registry Error", "Please enter your email"
            )
            return

        register = self.db.register_user(usr, psw, eml)

        if register:
            QtWidgets.QMessageBox.information(
                self, "Welcome", f"Account {usr} created successfully"
            )
            self.username_field.clear()
            self.email_field.clear()
            self.password_field.clear()

        else:
            QtWidgets.QMessageBox.warning(self, "Failed", "Username taken")

    def handle_login(self):
        usr = self.username_field.text().strip()
        psw = self.password_field.text().strip()

        conn = sqlite3.connect(self.db.dbname)
        cursor = conn.cursor()

        cursor.execute("SELECT id, passw FROM user WHERE name LIKE ?", (usr,))
        match = cursor.fetchone()

        if not match:
            QtWidgets.QMessageBox.warning(self, "Error", "User not found")
            self.username_field.clear()
            self.email_field.clear()
            self.password_field.clear()
            conn.close()
            return
        else:
            hashed = match[1]
            if self.db.pass_incrypter(psw) != hashed:
                QtWidgets.QMessageBox.warning(self, "Error", "Incorrect password")
                self.password_field.clear()
                conn.close()
                return
            conn.close()

            # aqedan gadadis main menushi
            logged_in_id = match[0]
            self.main_menu_window = MainMenu(user_id=logged_in_id)
            self.main_menu_window.show()
            self.hide()


if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)

    app.setStyle("Fusion")
    app.setStyleSheet(MODERN_THEME)

    window = Registration()
    window.setWindowTitle("SavePoint")
    window.show()

    sys.exit(app.exec_())
