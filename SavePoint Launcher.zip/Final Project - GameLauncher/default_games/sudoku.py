import tkinter as tk
from tkinter import messagebox


class SudokuGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Sudoku Game")
        self.root.geometry("420x500")
        self.root.resizable(False, False)

        # Base puzzle (0 represents empty cells)
        self.initial_board = [
            [5, 3, 0, 0, 7, 0, 0, 0, 0],
            [6, 0, 0, 1, 9, 5, 0, 0, 0],
            [0, 9, 8, 0, 0, 0, 0, 6, 0],
            [8, 0, 0, 0, 6, 0, 0, 0, 3],
            [4, 0, 0, 8, 0, 3, 0, 0, 1],
            [7, 0, 0, 0, 2, 0, 0, 0, 6],
            [0, 6, 0, 0, 0, 0, 2, 8, 0],
            [0, 0, 0, 4, 1, 9, 0, 0, 5],
            [0, 0, 0, 0, 8, 0, 0, 7, 9]
        ]

        # Complete solution for verification
        self.solution = [
            [5, 3, 4, 6, 7, 8, 9, 1, 2],
            [6, 7, 2, 1, 9, 5, 3, 4, 8],
            [1, 9, 8, 3, 4, 2, 5, 6, 7],
            [8, 5, 9, 7, 6, 1, 4, 2, 3],
            [4, 2, 6, 8, 5, 3, 7, 9, 1],
            [7, 1, 3, 9, 2, 4, 8, 5, 6],
            [9, 6, 1, 5, 3, 7, 2, 8, 4],
            [2, 8, 7, 4, 1, 9, 6, 3, 5],
            [3, 4, 5, 2, 8, 6, 1, 7, 9]
        ]

        self.cells = {}
        self.create_grid()
        self.create_buttons()

    def create_grid(self):
        # Frame container for the 9x9 board
        board_frame = tk.Frame(self.root, bg="black", bd=2)
        board_frame.pack(padx=10, pady=10)

        # Register input validation rule (only allow numbers 1-9 or empty)
        vcmd = (self.root.register(self.validate_input), "%P")

        for r in range(9):
            for c in range(9):
                # Calculate padding to thicker lines for 3x3 subgrid separation
                pad_x = (3 if c % 3 == 0 and c > 0 else 0, 3 if c == 8 else 0)
                pad_y = (3 if r % 3 == 0 and r > 0 else 0, 3 if r == 8 else 0)

                # Container frame for cell styling
                cell_frame = tk.Frame(board_frame, bg="gray")
                cell_frame.grid(row=r, column=c, padx=pad_x, pady=pad_y)

                val = self.initial_board[r][c]

                if val != 0:
                    # Starting numbers are labels (unchangeable)
                    lbl = tk.Label(cell_frame, text=str(val), width=2, height=1,
                                   font=("Arial", 18, "bold"), bg="#E0E0E0", fg="black")
                    lbl.pack()
                    self.cells[(r, c)] = ('fixed', val)
                else:
                    # User input cells use Entry widgets
                    entry = tk.Entry(cell_frame, width=2, font=("Arial", 18),
                                     justify="center", bd=1, validate="key", validatecommand=vcmd)
                    entry.pack()
                    self.cells[(r, c)] = ('input', entry)

    def validate_input(self, text):
        # Reject string if it is longer than 1 character or not a digit between 1 and 9
        if len(text) > 1:
            return False
        if text == "":
            return True
        return text.isdigit() and text in "123456789"

    def create_buttons(self):
        # Action button panel
        btn_frame = tk.Frame(self.root)
        btn_frame.pack(pady=15)

        check_btn = tk.Button(btn_frame, text="Check Solution", font=("Arial", 12, "bold"),
                              bg="#4CAF50", fg="white", command=self.check_solution)
        check_btn.grid(row=0, column=0, padx=10)

        clear_btn = tk.Button(btn_frame, text="Clear Answers", font=("Arial", 12),
                              bg="#f44336", fg="white", command=self.clear_answers)
        clear_btn.grid(row=0, column=1, padx=10)

    def check_solution(self):
        for r in range(9):
            for c in range(9):
                cell_type, obj = self.cells[(r, c)]
                if cell_type == 'input':
                    user_val = obj.get()
                    if user_val == "":
                        messagebox.showwarning("Incomplete", "Please fill out all cells before checking!")
                        return
                    if int(user_val) != self.solution[r][c]:
                        messagebox.showerror("Incorrect", f"Mistake found at Row {r + 1}, Column {c + 1}!")
                        return

        messagebox.showinfo("Success", "Congratulations! You solved the puzzle perfectly!")

    def clear_answers(self):
        for r in range(9):
            for c in range(9):
                cell_type, obj = self.cells[(r, c)]
                if cell_type == 'input':
                    obj.delete(0, tk.END)


if __name__ == "__main__":
    window = tk.Tk()
    app = SudokuGUI(window)
    window.mainloop()