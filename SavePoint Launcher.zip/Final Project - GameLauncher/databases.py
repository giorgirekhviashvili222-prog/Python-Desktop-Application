import hashlib
import sqlite3
from tkinter.constants import INSERT


# USERDATABASE
class UserDatabase:
    def __init__(self, dbname="users.db"):
        self.dbname = dbname
        self.create_table()

    # qmins cxrils
    def create_table(self):
        conn = sqlite3.connect(self.dbname)
        cursor = conn.cursor()
        cursor.execute("""CREATE TABLE IF NOT EXISTS user (
            id INTEGER PRIMARY KEY AUTOINCREMENT, 
            name VARCHAR (32) UNIQUE NOT NULL, 
            email VARCHAR (255) UNIQUE NOT NULL,
            passw VARCHAR (32) NOT NULL, 
            pfp_path TEXT DEFAULT ':/images/defaultpfp.PNG'
            )""")
        conn.commit()
        conn.close()

    # paroli brundeba dashifrulad
    def pass_incrypter(self, password):
        return hashlib.sha256(password.encode()).hexdigest()

    # momxmarebels amatebs cxrilshi
    def register_user(self, name, passw, email):
        conn = None
        try:
            conn = sqlite3.connect(self.dbname)
            cursor = conn.cursor()
            cursor.execute(
                "INSERT INTO user (name, email, passw) VALUES (?, ?, ?)",
                (name, email, self.pass_incrypter(passw)),
            )
            conn.commit()
            conn.close()
            return True
        except sqlite3.Error as e:
            if conn is not None:
                conn.close()
            print(f"{e}")
            return False

    def change_user(self, new_user, user, passw):
        conn = None
        try:
            conn = sqlite3.connect(self.dbname)
            cursor = conn.cursor()
            cursor.execute(
                "UPDATE user SET name = ? WHERE name = ? AND passw = ?",
                (new_user, user, self.pass_incrypter(passw)),
            )
            conn.commit()
            if cursor.rowcount == 0:
                conn.close()
                return False, "User not found or password incorrect"
            conn.close()
            return True, "Success"
        except sqlite3.Error as e:
            if conn is not None:
                conn.close()
            return False, str(e)

    def change_email(self, user, passw, new_email):
        conn = None
        try:
            conn = sqlite3.connect(self.dbname)
            cursor = conn.cursor()
            cursor.execute(
                "UPDATE user SET email = ? WHERE name = ? AND passw = ?",
                (new_email, user, self.pass_incrypter(passw)),
            )
            conn.commit()
            if cursor.rowcount == 0:
                conn.close()
                return False, "User not found or password incorrect"
            conn.close()
            return True, "Success"
        except sqlite3.Error as e:
            if conn is not None:
                conn.close()
            return False, str(e)

    def change_pass(self, user, passw, new_passw):
        conn = None
        try:
            conn = sqlite3.connect(self.dbname)
            cursor = conn.cursor()
            cursor.execute(
                "UPDATE user SET passw = ? WHERE passw = ? AND name = ?",
                (self.pass_incrypter(new_passw), self.pass_incrypter(passw), user),
            )
            conn.commit()
            if cursor.rowcount == 0:
                conn.close()
                return False, "User not found or password incorrect"
            conn.close()
            return True, "Success"
        except sqlite3.Error as e:
            if conn is not None:
                conn.close()
            return False, str(e)

    def update_avatar(self, user, pfp_path):
        conn = None
        try:
            conn = sqlite3.connect(self.dbname)
            cursor = conn.cursor()
            cursor.execute(
                "UPDATE user SET pfp_path = ? WHERE name = ?", (pfp_path, user)
            )
            conn.commit()
            conn.close()
            return True
        except sqlite3.Error as e:
            if conn is not None:
                conn.close()
            print(f"{e}")
            return False


# GAMEDATABASE
class GameDatabase:
    def __init__(self, dbname="games.db"):
        self.dbname = dbname
        self.create_table()

    # damatebuili tamashebi romlebis cxrili
    """აქ ყველგან category სვეტი მივუმატე ფუნქციებს"""

    def create_table(self):
        conn = sqlite3.connect(self.dbname)
        cursor = conn.cursor()

        cursor.execute('''
                        CREATE TABLE IF NOT EXISTS games(
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        user_id INT,
                        game_name TEXT NOT NULL,
                        game_path TEXT NOT NULL,
                        icon_path BLOB NOT NULL,
                        play_time INTEGER DEFAULT 0,
                        category TEXT DEFAULT "All Categories",
                        achievement TEXT DEFAULT "NONE",
                            
                        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                        UNIQUE(user_id, game_path)  
                          )
                       ''')

        conn.commit()
        conn.close()

    # tamashis damateba
    def insert_game(self, user_id, gname, gpath, game_icon_path, category):
        try:
            conn = sqlite3.connect(self.dbname)
            cursor = conn.cursor()
            cursor.execute(
                """INSERT INTO games(user_id, game_name, game_path, icon_path, category)
                           VALUES (?, ?, ?, ?, ?)""",
                (user_id, gname, gpath, game_icon_path, category),
            )
            conn.commit()
            conn.close()
            return True
        except sqlite3.Error as e:
            print(f"Database Error {e}")
            return False
